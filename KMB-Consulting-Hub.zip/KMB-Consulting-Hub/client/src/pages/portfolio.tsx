import { useTranslation } from "react-i18next";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { motion } from "framer-motion";

const projects = [
  {
    title: "Offshore Gas Field HSE Management",
    client: "Shell / PMS",
    category: "Oil & Gas",
    image: "https://images.unsplash.com/photo-1566937169390-7be4c63b8a0e?q=80&w=2070&auto=format&fit=crop",
    desc: "Achieved 1 Million safe working hours in WDDM Phase 10 & 11. Implemented full HSE digital tracking system.",
    tags: ["HSE", "Zero Accidents", "Offshore"]
  },
  {
    title: "Net Zero Strategy Implementation",
    client: "EGPC",
    category: "Sustainability",
    image: "https://images.unsplash.com/photo-1497435334941-8c899ee9e8e9?q=80&w=2074&auto=format&fit=crop",
    desc: "100% digitalization of energy transition data. Developed comprehensive carbon reduction roadmap.",
    tags: ["Net Zero", "Digitalization", "Strategy"]
  },
  {
    title: "Chemical Plant Process Safety",
    client: "Obegi Chemicals",
    category: "Manufacturing",
    image: "https://images.unsplash.com/photo-1581093450021-4a7360e9a6b5?q=80&w=2070&auto=format&fit=crop",
    desc: "Optimized production capacity to 150 Ton/Day while ensuring zero process safety incidents.",
    tags: ["Process Safety", "Optimization", "Chemicals"]
  },
  {
    title: "Waste Reduction Program",
    client: "Coveris Egypt",
    category: "Environment",
    image: "https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?q=80&w=2070&auto=format&fit=crop",
    desc: "Reduced resin waste by 60% through process control improvements and staff training.",
    tags: ["Waste Management", "Efficiency", "Green"]
  }
];

export default function Portfolio() {
  const { t } = useTranslation();

  return (
    <div className="pt-8 pb-20">
      <div className="bg-primary text-white py-16 mb-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4">{t("nav.portfolio")}</h1>
          <p className="text-xl opacity-90 max-w-2xl mx-auto">
             Showcasing our success stories in HSE excellence and sustainability transformation.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8">
          {projects.map((project, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: i * 0.1 }}
            >
              <Card className="overflow-hidden hover:shadow-lg transition-shadow border-none h-full flex flex-col">
                <div className="h-64 overflow-hidden relative group">
                  <div className="absolute inset-0 bg-primary/20 group-hover:bg-transparent transition-colors z-10" />
                  <img 
                    src={project.image} 
                    alt={project.title} 
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute top-4 right-4 z-20">
                    <Badge variant="secondary" className="bg-white/90 text-primary hover:bg-white">{project.category}</Badge>
                  </div>
                </div>
                <CardHeader>
                  <CardTitle className="text-xl text-primary">{project.title}</CardTitle>
                  <CardDescription className="text-secondary font-medium">{project.client}</CardDescription>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <p className="text-muted-foreground mb-6">
                    {project.desc}
                  </p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map(tag => (
                      <Badge key={tag} variant="outline" className="border-primary/10 text-primary/70">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}