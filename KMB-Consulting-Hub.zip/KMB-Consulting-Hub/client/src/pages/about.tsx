import { useTranslation } from "react-i18next";
import { experience, education, services } from "@/lib/data";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { GraduationCap, Briefcase, Award } from "lucide-react";
import { motion } from "framer-motion";

export default function About() {
  const { t } = useTranslation();

  return (
    <div className="pt-8 pb-20">
      {/* Header */}
      <div className="bg-primary text-white py-16 mb-12">
        <div className="container mx-auto px-4">
          <h1 className="text-4xl font-bold mb-4">{t("about.title")}</h1>
          <p className="text-xl opacity-90 max-w-2xl">{t("about.summary")}</p>
        </div>
      </div>

      <div className="container mx-auto px-4 grid lg:grid-cols-3 gap-12">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-12">
          
          {/* Experience */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <Briefcase className="text-secondary h-6 w-6" />
              <h2 className="text-2xl font-bold text-primary">Professional Experience</h2>
            </div>
            
            <div className="space-y-6">
              {experience.map((job, i) => (
                <motion.div 
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="relative pl-8 border-l-2 border-muted hover:border-secondary transition-colors"
                >
                  <div className="absolute -left-[9px] top-0 w-4 h-4 rounded-full bg-background border-2 border-secondary" />
                  <h3 className="text-xl font-bold text-foreground">{job.role}</h3>
                  <div className="text-secondary font-medium mb-2">{job.company} | {job.period}</div>
                  <p className="text-muted-foreground leading-relaxed">{job.desc}</p>
                </motion.div>
              ))}
            </div>
          </section>

          {/* Education */}
          <section>
            <div className="flex items-center gap-3 mb-6">
              <GraduationCap className="text-secondary h-6 w-6" />
              <h2 className="text-2xl font-bold text-primary">Education</h2>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              {education.map((edu, i) => (
                <Card key={i} className="border-none shadow-sm bg-muted/30">
                  <CardHeader>
                    <CardTitle className="text-lg">{edu.school}</CardTitle>
                    <div className="text-sm text-muted-foreground">{edu.year}</div>
                  </CardHeader>
                  <CardContent>
                    <div className="font-semibold text-primary mb-1">{edu.degree}</div>
                    <div className="text-sm text-secondary font-medium">{edu.grade}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </section>

        </div>

        {/* Sidebar */}
        <div className="space-y-8">
          <Card>
             <CardHeader>
               <CardTitle className="flex items-center gap-2">
                 <Award className="text-secondary h-5 w-5" /> Certifications
               </CardTitle>
             </CardHeader>
             <CardContent className="space-y-3">
               {[
                 "ISO 45001 Lead Auditor",
                 "ISO 14001 Lead Auditor",
                 "NEBOSH IGC",
                 "ESG Strategy & Reporting",
                 "Carbon Footprint Analyst",
                 "Food Safety ISO 22000"
               ].map((cert, i) => (
                 <div key={i} className="flex items-center justify-between p-2 bg-muted/50 rounded text-sm">
                   <span>{cert}</span>
                   <Badge variant="secondary" className="text-[10px]">Verified</Badge>
                 </div>
               ))}
             </CardContent>
          </Card>

           <Card className="bg-primary text-white border-none">
             <CardHeader>
               <CardTitle>Skills</CardTitle>
             </CardHeader>
             <CardContent className="flex flex-wrap gap-2">
               {[
                 "Risk Assessment", "HSE Auditing", "Sustainability Reporting", 
                 "Power BI", "Data Analysis", "Crisis Management", 
                 "Training & Coaching", "Compliance", "Strategic Planning"
               ].map((skill, i) => (
                 <Badge key={i} variant="outline" className="border-white/20 hover:bg-white/10 text-white">
                   {skill}
                 </Badge>
               ))}
             </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}