import { useState } from "react";
import { Link } from "wouter";
import { 
  LayoutDashboard, 
  Users, 
  FileText, 
  Settings, 
  LogOut, 
  Menu, 
  BarChart3,
  Bell
} from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Bar, BarChart, ResponsiveContainer, XAxis, YAxis, Tooltip } from "recharts";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";

// Mock Data
const data = [
  { name: "Jan", audits: 4 },
  { name: "Feb", audits: 3 },
  { name: "Mar", audits: 2 },
  { name: "Apr", audits: 6 },
  { name: "May", audits: 8 },
  { name: "Jun", audits: 5 },
];

const recentInquiries = [
  { id: 1, client: "PetroCo Egypt", service: "HSE Audit", status: "Pending", date: "2024-02-05" },
  { id: 2, client: "GreenEnergy Ltd", service: "Carbon Footprint", status: "In Progress", date: "2024-02-04" },
  { id: 3, client: "Alex Foods", service: "ISO 22000", status: "Completed", date: "2024-02-01" },
];

export default function Dashboard() {
  const [sidebarOpen, setSidebarOpen] = useState(true);

  return (
    <div className="min-h-screen bg-gray-100 dark:bg-gray-900 flex">
      {/* Sidebar */}
      <aside className={cn(
        "fixed inset-y-0 left-0 z-50 w-64 bg-primary text-primary-foreground transition-transform duration-300 ease-in-out lg:translate-x-0 lg:static lg:inset-0",
        sidebarOpen ? "translate-x-0" : "-translate-x-full"
      )}>
        <div className="h-16 flex items-center px-6 font-bold text-xl border-b border-primary-foreground/10">
          KMB Admin
        </div>
        <nav className="p-4 space-y-2">
          <Button variant="ghost" className="w-full justify-start text-primary-foreground/80 hover:text-white hover:bg-white/10">
            <LayoutDashboard className="mr-2 h-4 w-4" /> Dashboard
          </Button>
          <Button variant="ghost" className="w-full justify-start text-primary-foreground/80 hover:text-white hover:bg-white/10">
            <Users className="mr-2 h-4 w-4" /> Clients
          </Button>
          <Button variant="ghost" className="w-full justify-start text-primary-foreground/80 hover:text-white hover:bg-white/10">
            <FileText className="mr-2 h-4 w-4" /> Service Requests
          </Button>
          <Button variant="ghost" className="w-full justify-start text-primary-foreground/80 hover:text-white hover:bg-white/10">
            <BarChart3 className="mr-2 h-4 w-4" /> Reports
          </Button>
          <Button variant="ghost" className="w-full justify-start text-primary-foreground/80 hover:text-white hover:bg-white/10">
            <Settings className="mr-2 h-4 w-4" /> Settings
          </Button>
        </nav>
        <div className="absolute bottom-4 left-4 right-4">
          <Link href="/">
            <Button variant="destructive" className="w-full justify-start">
              <LogOut className="mr-2 h-4 w-4" /> Logout to Home
            </Button>
          </Link>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-y-auto">
        <header className="bg-white dark:bg-gray-800 h-16 shadow-sm flex items-center justify-between px-6 sticky top-0 z-40">
           <Button variant="ghost" size="icon" className="lg:hidden" onClick={() => setSidebarOpen(!sidebarOpen)}>
             <Menu />
           </Button>
           <h2 className="text-xl font-semibold text-gray-800 dark:text-gray-100">Overview</h2>
           <div className="flex items-center gap-4">
             <Button variant="ghost" size="icon">
               <Bell className="h-5 w-5" />
             </Button>
             <div className="h-8 w-8 bg-secondary rounded-full flex items-center justify-center text-white font-bold">KM</div>
           </div>
        </header>

        <div className="p-6 space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Total Audits</CardTitle>
                <FileText className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">28</div>
                <p className="text-xs text-muted-foreground">+12% from last month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Active Clients</CardTitle>
                <Users className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">14</div>
                <p className="text-xs text-muted-foreground">+2 new this month</p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium">Pending Requests</CardTitle>
                <Bell className="h-4 w-4 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">5</div>
                <p className="text-xs text-muted-foreground">Requires attention</p>
              </CardContent>
            </Card>
          </div>

          <div className="grid lg:grid-cols-2 gap-6">
            {/* Chart */}
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Audit Performance</CardTitle>
                <CardDescription>Monthly audits completed</CardDescription>
              </CardHeader>
              <CardContent className="h-[300px]">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={data}>
                    <XAxis dataKey="name" fontSize={12} tickLine={false} axisLine={false} />
                    <YAxis fontSize={12} tickLine={false} axisLine={false} tickFormatter={(value) => `${value}`} />
                    <Tooltip />
                    <Bar dataKey="audits" fill="hsl(var(--secondary))" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            {/* Recent Table */}
            <Card className="col-span-1">
              <CardHeader>
                <CardTitle>Recent Inquiries</CardTitle>
                <CardDescription>Latest service requests from website</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Client</TableHead>
                      <TableHead>Service</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentInquiries.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell className="font-medium">{item.client}</TableCell>
                        <TableCell>{item.service}</TableCell>
                        <TableCell>
                          <Badge 
                            variant={item.status === 'Completed' ? 'default' : item.status === 'In Progress' ? 'secondary' : 'outline'}
                            className={item.status === 'Completed' ? 'bg-green-500 hover:bg-green-600' : ''}
                          >
                            {item.status}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}