import Hero from "@/components/hero";
import ServiceCard from "@/components/service-card";
import { services } from "@/lib/data";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";
import { CheckCircle2 } from "lucide-react";

export default function Home() {
  const { t } = useTranslation();

  return (
    <div className="flex flex-col gap-0">
      <Hero />
      
      {/* About Section Preview */}
      <section className="py-20 bg-background">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <motion.div
              initial={{ opacity: 0, x: -50 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <h4 className="text-secondary font-bold text-sm uppercase tracking-wider mb-2">Who We Are</h4>
              <h2 className="text-3xl md:text-4xl font-bold mb-6 text-primary">{t("about.title")}</h2>
              <p className="text-muted-foreground text-lg mb-6 leading-relaxed">
                {t("about.summary")}
              </p>
              
              <div className="space-y-4 mb-8">
                {["12+ Years Experience", "ISO Certified Experts", "Offshore & Onshore Specialists", "Digital HSE Solutions"].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <CheckCircle2 className="text-secondary h-5 w-5" />
                    <span className="font-medium text-foreground/80">{item}</span>
                  </div>
                ))}
              </div>
            </motion.div>
            
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="relative"
            >
              <div className="absolute inset-0 bg-primary/5 rounded-2xl transform rotate-3" />
              <img 
                src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?q=80&w=2070&auto=format&fit=crop" 
                alt="Consulting Meeting" 
                className="rounded-2xl shadow-xl relative z-10 w-full object-cover h-[400px]"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-primary">{t("services.title")}</h2>
            <div className="h-1 w-20 bg-secondary mx-auto rounded-full" />
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <ServiceCard 
                key={service.id}
                icon={service.icon}
                title={t(service.titleKey)}
                description={t(service.descKey)}
                colorClass={service.color}
                index={index}
              />
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary text-primary-foreground relative overflow-hidden">
        <div className="absolute inset-0 opacity-10" style={{ backgroundImage: "url('/pattern-bg.png')" }} />
        <div className="container mx-auto px-4 relative z-10 text-center">
          <h2 className="text-3xl font-bold mb-6">Ready to elevate your HSE & Sustainability standards?</h2>
          <p className="text-lg text-primary-foreground/80 max-w-2xl mx-auto mb-8">
            Contact us today for a free consultation and discover how we can help your business achieve compliance and excellence.
          </p>
          <a 
             href="/contact" 
             className="inline-flex items-center justify-center px-8 py-3 bg-secondary text-white font-semibold rounded-md hover:bg-secondary/90 transition-colors"
          >
            {t("hero.contact")}
          </a>
        </div>
      </section>
    </div>
  );
}