import { useTranslation } from "react-i18next";
import { services } from "@/lib/data";
import ServiceCard from "@/components/service-card";

export default function Services() {
  const { t } = useTranslation();

  return (
    <div className="pt-8 pb-20">
      <div className="bg-muted py-16 mb-12">
        <div className="container mx-auto px-4 text-center">
          <h1 className="text-4xl font-bold mb-4 text-primary">{t("services.title")}</h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
             Comprehensive solutions tailored to meet international standards and local regulations.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <ServiceCard 
              key={service.id}
              icon={service.icon}
              title={t(service.titleKey)}
              description={t(service.descKey)}
              colorClass={service.color}
              index={index}
            />
          ))}
        </div>

        {/* Detailed Info Section (Mock) */}
        <div className="mt-20 space-y-20">
          <div className="grid md:grid-cols-2 gap-12 items-center">
             <img 
               src="https://images.unsplash.com/photo-1581094794329-c8112a89af12?q=80&w=2070&auto=format&fit=crop" 
               alt="Industrial Safety" 
               className="rounded-2xl shadow-lg"
             />
             <div>
               <h3 className="text-3xl font-bold mb-6 text-primary">Industrial HSE Excellence</h3>
               <p className="text-lg text-muted-foreground mb-6">
                 We provide end-to-end HSE management for high-risk industries including Oil & Gas and Construction. From gap analysis to full system implementation.
               </p>
               <ul className="space-y-2 list-disc pl-5 text-foreground/80">
                 <li>Site Inspections & Audits</li>
                 <li>Emergency Response Planning</li>
                 <li>Safety Training Programs</li>
                 <li>Behavior Based Safety (BBS)</li>
               </ul>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
}