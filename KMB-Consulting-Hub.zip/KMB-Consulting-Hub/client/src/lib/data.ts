import { ShieldCheck, Leaf, Globe, Utensils, ClipboardCheck, LayoutDashboard } from "lucide-react";

export const services = [
  {
    id: "hse",
    icon: ShieldCheck,
    titleKey: "services.hse",
    descKey: "services.hse.desc",
    color: "text-blue-600"
  },
  {
    id: "env",
    icon: Leaf,
    titleKey: "services.env",
    descKey: "services.env.desc",
    color: "text-green-600"
  },
  {
    id: "carbon",
    icon: Globe,
    titleKey: "services.carbon",
    descKey: "services.carbon.desc",
    color: "text-teal-500"
  },
  {
    id: "food",
    icon: Utensils,
    titleKey: "services.food",
    descKey: "services.food.desc",
    color: "text-orange-500"
  },
  {
    id: "audit",
    icon: ClipboardCheck,
    titleKey: "services.audit",
    descKey: "services.audit.desc",
    color: "text-purple-600"
  },
  {
    id: "digital",
    icon: LayoutDashboard,
    titleKey: "services.digital",
    descKey: "services.digital.desc",
    color: "text-indigo-600"
  }
];

export const experience = [
  {
    company: "Petroleum Marine Services (PMS)",
    role: "HSE Projects Manager",
    period: "2021 - Present",
    desc: "Managing HSE for major offshore projects, evaluating subcontractors, and leading HAZID/HIRA meetings."
  },
  {
    company: "Coveris Egypt",
    role: "HSE & Process Control Engineer",
    period: "2020 - 2021",
    desc: "Monitored process control in extrusion and printing departments, ensuring production quality and waste reduction."
  },
  {
    company: "Obegi Chemicals",
    role: "Production Section Head",
    period: "2017 - 2020",
    desc: "Supervised operations to achieve optimum process performance and production plans."
  },
  {
    company: "Amryia Pharma",
    role: "HSE Engineer",
    period: "2015 - 2017",
    desc: "Implemented ISO 9001, 14001, and 45001 standards and conducted risk assessments."
  }
];

export const education = [
  {
    school: "Arab Academy for Science, Technology & Maritime Transport",
    degree: "Master of Business Administration (Strategic Management)",
    grade: "3.54 (Excellent)",
    year: "2022 - 2024"
  },
  {
    school: "Alexandria University",
    degree: "Bachelor of Science in Chemistry",
    grade: "Good",
    year: "2010 - 2013"
  }
];