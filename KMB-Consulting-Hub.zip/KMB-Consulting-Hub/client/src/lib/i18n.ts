import i18n from "i18next";
import { initReactI18next } from "react-i18next";

const resources = {
  en: {
    translation: {
      "nav.home": "Home",
      "nav.about": "About",
      "nav.services": "Services",
      "nav.portfolio": "Portfolio",
      "nav.blog": "Blog",
      "nav.contact": "Contact",
      "nav.dashboard": "Admin",
      
      "hero.title": "Leading HSE, ESG & Sustainability Solutions",
      "hero.subtitle": "Empowering industries with world-class safety, environmental compliance, and digital transformation strategies.",
      "hero.cta": "Explore Services",
      "hero.contact": "Get in Touch",

      "about.title": "About KMB Consulting",
      "about.summary": "Founded by Kareem Mohammed, an HSE Project Manager with over 12 years of experience in Offshore, Oil & Gas, and Petrochemicals. We specialize in strategic safety management, carbon footprint accounting, and digital HSE solutions.",

      "services.title": "Our Expertise",
      "services.hse": "HSE Management Systems",
      "services.hse.desc": "ISO 45001 & ISO 14001 implementation, risk assessment, and safety culture transformation.",
      "services.env": "Environmental Compliance",
      "services.env.desc": "Impact assessments, waste management, and regulatory compliance for industrial projects.",
      "services.carbon": "Carbon & Net Zero",
      "services.carbon.desc": "Carbon footprint calculation, CBAM reporting, and Net Zero strategy development.",
      "services.food": "Food Safety",
      "services.food.desc": "HACCP, ISO 22000, and FSSC certification support for catering and manufacturing.",
      "services.audit": "Auditing & Assurance",
      "services.audit.desc": "Internal and external audits to ensure compliance with international standards.",
      "services.digital": "Digital HSE Solutions",
      "services.digital.desc": "Custom dashboards, mobile apps for safety reporting, and data analytics.",

      "contact.title": "Contact Us",
      "contact.name": "Name",
      "contact.email": "Email",
      "contact.message": "Message",
      "contact.submit": "Send Message",
      
      "footer.rights": "© 2024 KMB Consulting. All rights reserved.",
    }
  },
  ar: {
    translation: {
      "nav.home": "الرئيسية",
      "nav.about": "عن الشركة",
      "nav.services": "خدماتنا",
      "nav.portfolio": "أعمالنا",
      "nav.blog": "المدونة",
      "nav.contact": "اتصل بنا",
      "nav.dashboard": "لوحة التحكم",

      "hero.title": "ريادة في حلول السلامة والصحة المهنية والاستدامة",
      "hero.subtitle": "نمكن المؤسسات من تحقيق أعلى معايير السلامة والامتثال البيئي والتحول الرقمي.",
      "hero.cta": "استكشف خدماتنا",
      "hero.contact": "تواصل معنا",

      "about.title": "عن KMB للاستشارات",
      "about.summary": "تأسست بواسطة كريم محمد، مدير مشاريع HSE بخبرة تزيد عن 12 عاماً في مجالات الأوفشور والنفط والغاز. نحن متخصصون في إدارة السلامة الاستراتيجية، حساب البصمة الكربونية، وحلول HSE الرقمية.",

      "services.title": "خدماتنا",
      "services.hse": "نظم إدارة الصحة والسلامة",
      "services.hse.desc": "تطبيق ISO 45001 و ISO 14001، تقييم المخاطر، وتحويل ثقافة السلامة.",
      "services.env": "الامتثال البيئي",
      "services.env.desc": "تقييم الأثر البيئي، إدارة النفايات، والامتثال لللوائح في المشاريع الصناعية.",
      "services.carbon": "الكربون والحياد الصفري",
      "services.carbon.desc": "حساب البصمة الكربونية، تقارير CBAM، وتطوير استراتيجيات الحياد الصفري.",
      "services.food": "سلامة الغذاء",
      "services.food.desc": "دعم شهادات HACCP و ISO 22000 و FSSC لقطاعات التغذية والتصنيع.",
      "services.audit": "التدقيق والضمان",
      "services.audit.desc": "تدقيق داخلي وخارجي لضمان الامتثال للمعايير الدولية.",
      "services.digital": "حلول HSE الرقمية",
      "services.digital.desc": "لوحات معلومات مخصصة، تطبيقات موبايل لتقارير السلامة، وتحليل البيانات.",

      "contact.title": "تواصل معنا",
      "contact.name": "الاسم",
      "contact.email": "البريد الإلكتروني",
      "contact.message": "الرسالة",
      "contact.submit": "إرسال الرسالة",

      "footer.rights": "© 2024 KMB للاستشارات. جميع الحقوق محفوظة.",
    }
  }
};

i18n
  .use(initReactI18next)
  .init({
    resources,
    lng: "en", 
    interpolation: {
      escapeValue: false 
    }
  });

export default i18n;