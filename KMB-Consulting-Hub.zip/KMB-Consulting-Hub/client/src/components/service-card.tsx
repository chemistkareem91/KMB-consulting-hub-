import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { LucideIcon, ArrowRight, ArrowLeft } from "lucide-react";
import { useTranslation } from "react-i18next";
import { motion } from "framer-motion";

interface ServiceCardProps {
  icon: LucideIcon;
  title: string;
  description: string;
  colorClass: string;
  index: number;
}

export default function ServiceCard({ icon: Icon, title, description, colorClass, index }: ServiceCardProps) {
  const { i18n } = useTranslation();
  const isRTL = i18n.language === 'ar';
  const Arrow = isRTL ? ArrowLeft : ArrowRight;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: index * 0.1, duration: 0.5 }}
    >
      <Card className="h-full hover:shadow-xl transition-all duration-300 border-none shadow-md group overflow-hidden bg-white">
        <div className={`h-1 w-full ${colorClass.replace('text-', 'bg-')}`} />
        <CardHeader>
          <div className={`w-12 h-12 rounded-lg bg-gray-50 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform duration-300`}>
            <Icon className={`h-6 w-6 ${colorClass}`} />
          </div>
          <CardTitle className="text-xl group-hover:text-primary transition-colors">{title}</CardTitle>
        </CardHeader>
        <CardContent>
          <CardDescription className="text-base mb-4 leading-relaxed">
            {description}
          </CardDescription>
          <div className={`flex items-center text-sm font-medium ${colorClass} opacity-0 group-hover:opacity-100 transition-opacity translate-y-2 group-hover:translate-y-0`}>
            Read more <Arrow className="ml-1 h-3 w-3" />
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
}