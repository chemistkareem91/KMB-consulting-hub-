import { Link, useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import { useEffect, useState } from "react";
import { Menu, X, Globe, Phone, Mail, Linkedin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { 
  Sheet, 
  SheetContent, 
  SheetTrigger 
} from "@/components/ui/sheet";
import { cn } from "@/lib/utils";

export default function Layout({ children }: { children: React.ReactNode }) {
  const { t, i18n } = useTranslation();
  const [location] = useLocation();
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    document.documentElement.dir = i18n.language === "ar" ? "rtl" : "ltr";
    document.documentElement.lang = i18n.language;
  }, [i18n.language]);

  const toggleLang = () => {
    i18n.changeLanguage(i18n.language === "en" ? "ar" : "en");
  };

  const navItems = [
    { href: "/", label: t("nav.home") },
    { href: "/about", label: t("nav.about") },
    { href: "/services", label: t("nav.services") },
    { href: "/portfolio", label: t("nav.portfolio") },
    { href: "/contact", label: t("nav.contact") },
  ];

  return (
    <div className="min-h-screen flex flex-col font-sans bg-background text-foreground overflow-x-hidden">
      {/* Top Bar */}
      <div className="bg-primary text-primary-foreground py-2 text-xs px-4 hidden md:flex justify-between items-center">
        <div className="flex gap-4">
          <span className="flex items-center gap-1"><Mail size={12} /> info@kmb-consulting.com</span>
          <span className="flex items-center gap-1"><Phone size={12} /> +20 114 495 5223</span>
        </div>
        <div className="flex gap-4">
          <a href="#" className="hover:text-secondary transition-colors"><Linkedin size={14} /></a>
        </div>
      </div>

      {/* Navbar */}
      <header 
        className={cn(
          "sticky top-0 z-50 w-full transition-all duration-300 border-b",
          scrolled ? "bg-white/95 backdrop-blur-md shadow-sm border-gray-200" : "bg-white border-transparent"
        )}
      >
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/">
            <a className="flex items-center gap-2">
              <div className="w-8 h-8 bg-secondary rounded-sm flex items-center justify-center text-white font-bold text-xl">
                K
              </div>
              <span className="font-bold text-xl tracking-tight text-primary">
                KMB <span className="text-secondary">Consulting</span>
              </span>
            </a>
          </Link>

          {/* Desktop Nav */}
          <nav className="hidden md:flex items-center gap-8">
            {navItems.map((item) => (
              <Link key={item.href} href={item.href}>
                <a className={cn(
                  "text-sm font-medium transition-colors hover:text-secondary relative group",
                  location === item.href ? "text-primary" : "text-muted-foreground"
                )}>
                  {item.label}
                  <span className={cn(
                    "absolute -bottom-1 left-0 h-0.5 bg-secondary transition-all duration-300",
                    location === item.href ? "w-full" : "w-0 group-hover:w-full"
                  )}/>
                </a>
              </Link>
            ))}
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={toggleLang}
              className="flex items-center gap-2 text-muted-foreground hover:text-primary"
            >
              <Globe size={16} />
              {i18n.language === "en" ? "العربية" : "English"}
            </Button>
            <Link href="/dashboard">
              <Button size="sm" variant="outline" className="hidden lg:flex">
                 {t("nav.dashboard")}
              </Button>
            </Link>
          </nav>

          {/* Mobile Nav */}
          <div className="flex items-center gap-4 md:hidden">
            <Button 
              variant="ghost" 
              size="sm" 
              onClick={toggleLang}
            >
              {i18n.language === "en" ? "AR" : "EN"}
            </Button>
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon">
                  <Menu className="h-6 w-6" />
                </Button>
              </SheetTrigger>
              <SheetContent side={i18n.language === 'ar' ? 'right' : 'left'}>
                <nav className="flex flex-col gap-6 mt-10">
                  {navItems.map((item) => (
                    <Link key={item.href} href={item.href}>
                      <a className={cn(
                        "text-lg font-medium transition-colors hover:text-secondary",
                        location === item.href ? "text-primary" : "text-muted-foreground"
                      )}>
                        {item.label}
                      </a>
                    </Link>
                  ))}
                  <Link href="/dashboard">
                    <Button className="w-full mt-4">{t("nav.dashboard")}</Button>
                  </Link>
                </nav>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      <main className="flex-1">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-primary text-primary-foreground py-12">
        <div className="container mx-auto px-4 grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center gap-2 mb-4">
               <div className="w-8 h-8 bg-secondary rounded-sm flex items-center justify-center text-white font-bold text-xl">
                K
              </div>
              <span className="font-bold text-xl">KMB Consulting</span>
            </div>
            <p className="text-primary-foreground/70 text-sm leading-relaxed">
              {t("hero.subtitle")}
            </p>
          </div>
          
          <div>
            <h3 className="font-bold mb-4">{t("nav.services")}</h3>
            <ul className="space-y-2 text-sm text-primary-foreground/70">
              <li>{t("services.hse")}</li>
              <li>{t("services.env")}</li>
              <li>{t("services.carbon")}</li>
              <li>{t("services.food")}</li>
            </ul>
          </div>

          <div>
             <h3 className="font-bold mb-4">{t("nav.contact")}</h3>
             <ul className="space-y-2 text-sm text-primary-foreground/70">
               <li className="flex items-center gap-2"><Mail size={14}/> chemist.kareem1991@gmail.com</li>
               <li className="flex items-center gap-2"><Phone size={14}/> +20 114 495 5223</li>
               <li>Alexandria, Egypt</li>
             </ul>
          </div>
          
          <div>
             <h3 className="font-bold mb-4">Newsletter</h3>
             <div className="flex gap-2">
               <input 
                 type="email" 
                 placeholder="Email address" 
                 className="bg-white/10 border border-white/20 rounded px-3 py-2 text-sm w-full focus:outline-hidden focus:border-secondary"
               />
               <Button size="sm" variant="secondary">Go</Button>
             </div>
          </div>
        </div>
        <div className="container mx-auto px-4 mt-12 pt-8 border-t border-white/10 text-center text-xs text-primary-foreground/50">
          {t("footer.rights")}
        </div>
        
        {/* WhatsApp Float */}
        <a 
          href="https://wa.me/201144955223" 
          target="_blank"
          className="fixed bottom-6 right-6 bg-[#25D366] text-white p-3 rounded-full shadow-lg hover:scale-110 transition-transform z-50 flex items-center justify-center"
        >
          <Phone className="h-6 w-6" />
        </a>
      </footer>
    </div>
  );
}